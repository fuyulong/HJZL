TOSHIBA e-STUDIO-Serie

	Copyright(c) 2003-2012 TOSHIBA TEC CORPORATION Alle Rechte vorbehalten.
			7. Dezember 2012

Dieses Produkt unterliegt den folgenden Begrenzungen und Regeln.  Bitte lesen Sie diese Angaben vor der Verwendung durch.


--------------------------------------------------------------------------------
Druckertreiber
	f�r Windows (Universal 2/PS3/XPS)			Version 7.71.2651.1
	f�r Network-Fax						Version 2.3.65.0
--------------------------------------------------------------------------------

Regeln
======

1. Windows

- Windows Server 2008, Windows Server 2008 R2 und Windows Server 2012 unterst�tzen nur universelle und PS3-Druckertreiber.

- Wenn mithilfe von "Point-and-Print" ein auf dem Server installierter Druckertreiber auf einem Client-PC installiert wird und auf dem Client-PC der Standardwert auf der Registerkarte "Allgemein" des Druckertreibers unter "Einstellungen" festgelegt wird, wird er nicht zum Standardwert auf dem Client-PC, auch wenn im Druckertreiber auf dem Server "Normale Einstellungen" ge�ndert wird.

- Wenn N/W-Fax f�r FAX-�bertragung verwendet wird und wenn Sie eine Pause in der W�hlnummer einf�gen wollen, verwenden Sie das Zeichen � - � (Strich).

- In Windows 8 (32 Bit) werden die Dialogfelder, die beim Drucken eingeblendet werden (z. B. "Kennwort f�r vertraulichen Druck" und "Abteilungscode") in einem inaktiven Zustand angezeigt. Dies liegt daran, dass die Anwendung in Windows 8 (32 Bit) �ber WOW64 aufgerufen wird. Bitte machen Sie das angezeigte Dialogfeld aktiv, bevor Sie Einstellungen vornehmen.

- Wenn Bilder im Hochformat und Querformat auf den gleichen Blatt von "Mehrere Seiten pro Blatt" vorhanden sind, wird der Druck nicht durch Drehen eines der Bilder ausgef�hrt.  Er wird durch Verkleinerung ausgef�hrt.

- Wenn ein Originaldokument, das Grafiken im Hoch- und Querformat enth�lt, im Modus �2-seitiger Druck' gedruckt wird, kann es vorkommen, dass eine Grafik auf die n�chste Seite gedruckt wird, sobald sich deren Ausrichtung �ndert.

- Die Hilfe-Meldung erscheint nicht, auch wenn die Schaltfl�che "?" oben rechts im Bildschirm geklickt wird.

- Bei Verwendung eines Standard TCP/IP-Anschlusses unter Windows XP, �ndern Sie nicht den Vorgabe-Anschlussnamen.  Wenn der Anschlussname ge�ndert werden soll, �ndern Sie den Namen, �ffnen Sie Eigenschaften am Drucker und klicken Sie auf das Register Konfiguration, und dann auf die Schaltfl�che Jetzt aktualisieren, um den aktuell verwendeten e-STUDIO zu finden.

- Wenn der Druck in einer NetWare-Umgebung ausgef�hrt wird, kann SNMP-Kommunikation nicht sofort nach der Installation des Druckers ausgef�hrt werden.  �ffnen Sie Eigenschaften am Drucker und klicken Sie auf das Register Konfiguration, und dann auf die Schaltfl�che Jetzt Aktualisieren, um den aktuell verwendeten e-STUDIO zu finden.

- Wenn der PS3-Druckertreiber verwendet wird und der Adobe TypeManager Font den Druck ausf�hrt, wird dies ein Fehler. Verwenden Sie deshalb nicht den Adobe TypeManager Font. Verwenden Sie den PCL-Druckertreiber, wenn Sie den Adobe TypeManager Font verwenden m�ssen.

- Wenn LPR zum Drucken verwendet wird, deaktivieren Sie das Byte Counting.

- Beim Drucken eines Wasserzeichens kann das Resultat sich je nach Einstellungen von der Erwartung unterscheiden.  In diesem Fall drucken Sie das Waserzeichen erneut nach dem �ndern von Gr��e und Position von Wasserzeichen.  Es ist wirksam, das Wasserzeichen im Druckbereich zu platzieren.

- Nicht kompatibel mit TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3 und dem Druckertreiber TOSHIBA e-STUDIO Series XPS

Funktionen wie ?Profil�g, ?Wasserzeichen�g, ?Overlay�g und mit den Druckertreibern TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3, TOSHIBA e-STUDIO Series XPS erstellte exportierte Einstelldateien funktionieren nicht mit diesem Druckertreiber.
Erstellen Sie diese erneut mit diesem Druckertreiber.

- Beschrankungen bei der Verwendung von Profilen
1. <Inkompatibilitat zwischen Modellen mit Festplatte (HDD)/Modellen ohne HDD>
1.1. Wenn Sie in einem Modell mit HDD ein Profil laden, welches in einem Modell ohne HDD erstellt wurde, gehen alle Druckauftrage mit Ausnahme des normalen und Overlay-Drucks verloren.
Beenden Sie das Druckertreiber-Programm uber die Option Abbrechen und offnen Sie es zum Fortfahren erneut.

1.2 Wenn Sie in einem Modell ohne HDD ein Profil laden, welches in einem Modell mit HDD erstellt wurde, stehen alle Druckauftrage einschlieslich denen, die HDD benotigen, zur Auswahl.
Bitte wahlen Sie nicht die Druckauftrage aus, die HDD benotigen. Wenn Sie Druckauftrage senden, die HDD benotigen, werden diese im MFP geloscht.
Entnehmen Sie Details zu den Druckauftragen, die HDD benotigen, der Druckanleitung.

2. <Inkompatibilitat zwischen Modellen mit automatischer Duplexeinheit (ADU)/Modellen ohne ADU>
2.1. Wenn Sie in einem Modell mit ADU ein Profil laden, welches in einem Modell ohne ADU erstellt wurde, ist das 2-seitige Drucken deaktiviert.
Beenden Sie das Druckertreiber-Programm uber die Option Abbrechen und offnen Sie es zum Fortfahren erneut.

2.2. Wenn Sie in einem Modell ohne ADU ein Profil laden, welches in einem Modell mit ADU erstellt wurde, ist das 2-seitige Drucken aktiviert.
  Wahlen Sie das 2-seitige Drucken jedoch nicht. Wenn Sie einen 2-seitigen Druckauftrag senden, wird er nur 1-seitig gedruckt.

- Drucken aus einer Anwendung

(1) �bersicht
Obwohl einige Druckoptionen aus Ihrer Anwendung eingestellt werden k�nnen, verwenden Sie Ihre Anwendung nicht zur Druckeinstellung. Verwenden Sie Ihren Druckertreiber zum Einstellen von Druckoptionen.
Wenn Druck nach dem Einstellen Ihrer Anwendung ausgef�hrt wird, k�nnen unerwartete Ergebnisse auftreten oder die Verarbeitung kann lange dauern.
Stellen Sie nicht "Kollatieren" in Ihrer Anwendung ein.
Bei der Wahl eines Papierfachs f�r Ihre Anwendung k�nnen zwei "AutoSelect tray"-Anzeigen erscheinen. In diesem Fall w�hlen Sie das unten gezeigte "AutoSelect tray" (Autowahl-Fach).

(2) Microsoft Excel
Excel behandelt jedes Worksheet als einen Druckauftrag.  Die Einstellung im Druckertreiber-Bildschirm gelten nur f�r das erste Worksheet.

Wenn Sie mehr als eins in [Kopien] im Drucken-Dialog f�r Excel eingeben, markieren Sie nicht [Kollatieren].

(3) Adobe Acrobat 
Bei Verwendung von PS3 f�r den Druck k�nnen gedruckte Bilder vergr��ert oder verkleinert werden. Durch Verwendung von PCL6 oder PS3 mit den folgenden Druckeinstellungen k�nnen auch in diesem Fall Bilder der richtigen Gr��e ausgedruckt werden.
�ffnen Sie das Druckdialogfeld, um die Einstellungen f�r PS3 vorzunehmen.
- W�hlen Sie [An Papier anpassen] aus dem Men� [Seitenskalierung]. 
- Markieren Sie [Papierquelle nach PDF-Seitengr��e w�hlen]. 
(Beachten Sie, dass die Papiereinstellungen des Treibers nicht gelten, da die Papiergr��e der PDF Datei verwendet wird.)

(4) Adobe PageMaker
Bei Privatdruckvorg�ngen und Abteilungscode-Druckvorg�ngen unter Verwendung von WindowsPPD f�r Adobe PageMaker muss immer ein Code angegeben werden. Andernfalls wird eine Fehlernachricht gedruckt. 


- Point & Print vom Windows-Server

(1) Druck-Einrichtung, die "Standartwerte" des Servers eingestellt ist, kann m�glicherweise nicht auf der Client-Seite reflektiert werden, je nach der Kombination von Server-Betriebssystem und Client-Betriebssystem.

(2) Hinzuf�gen eines Point & Print (Windows Server - Client) Druckertreibers
<Hinzuf�gen eines 64-Bit- oder 32-Bit-Druckertreibers unter Windows Server 2003, wenn Client und Server einen unterschiedlichen Mikroprozessortyp aufweisen>
1. Geben Sie einen Drucker unter der Registerkarte Freigabe des Druckertreibers frei und klicken Sie auf �Zus�tzliche Treiber�, um x64 bzw. x86 auszuw�hlen.
2. W�hlen Sie eine Datei mit der Erweiterung .INF aus dem Druckertreiberpaket (x64 oder x86) aus.
3. Es wird eine CD-ROM der Windows Server 2003 (x64/x86) Produktreihe ben�tigt. Nach dem Einlegen der CD wird �NTPRINT.INF� automatisch aus dem Ordner �amd64� oder �i386� ausgelesen.
4. Da �MSXPSDRV.INF� ben�tigt wird, w�hlen Sie �%SYSTEMROOT%\System32\Spool\XPSEP\amd64� oder �%SYSTEMROOT%\System32\Spool\XPSEP\i386�.
5. (Falls die Client-CD, die in Schritt 2 oben zum Ausw�hlen des Treiberpakets benutzt wurde, bereits aus dem Laufwerk entnommen wurde) Legen Sie die CD erneut ein und weisen Sie den Ort f�r den x64- oder x86-Druckertreiber zu.

<Hinzuf�gen eines 64-Bit- oder 32-Bit-Druckertreibers unter Windows Vista, Windows 7, Windows Server 2008 oder Windows Server 2008 R2, wenn Client und Server einen unterschiedlichen Mikroprozessortyp aufweisen>
[Vorbereitung] Kopieren Sie den Ordner �ntprint.inf_********� im Ordner �%SYSTEMROOT%\system32\DriverStore\FileRepository� des Vista- oder Windows 7-Client auf den Vista- oder Windows 7-Server oder lassen Sie die Benutzer die Ordner teilen.
1. Geben Sie einen Drucker unter der Registerkarte �Freigabe� des Druckertreibers frei und klicken Sie auf �Zus�tzliche Treiber�, um x64 bzw. x86 auszuw�hlen.
2. W�hlen Sie eine Datei mit der Erweiterung .INF aus dem Druckertreiberpaket (x64 oder x86) aus.
3. Windows Media (x64-Prozessor) oder Windows Media (x86-Prozessor) ist erforderlich.  �ffnen Sie den Ordner �ntprint.inf_********� des Vista- oder Windows 7-Client und w�hlen Sie die Datei �ntprint.inf�.
4. Klicken Sie auf OK.


- XPS Printer Driver

(1) Wenn mit einem XPS-Druckertreiber unter Windows Vista 32-Bit �ber XPS-Viewer-EP oder unter Windows Vista 64-Bit �ber einen XPS-Viewer-EP gedruckt wird, treten folgende Probleme auf. Durch die Verwendung eines universellen Druckers oder eines PS3-Druckers lassen sich diese Probleme vermeiden.
1. Der eingegebene Abteilungscode wird ung�ltig, und der Job wird als nicht definierter Job behandelt. 
2. Beim privaten Drucken wird das zum Drucken eingegebene Passwort ung�ltig und das Eingabefeld erscheint leer.
3. Von TopAccessDocMon wird keine Ereignismeldung f�r den Abschluss des Druckvorgangs gesendet.
4. Die Job-Warteschlange kann nicht von TopAccessDocMon ausgedruckt oder gel�scht werden.
5. Der Dokumentenname wird nicht auf dem Touch-Panel des Ger�ts, in der Druckwarteschlange in TopAccessDocMon und auf den Bildschirmen Druckprotokoll und e-Filing in TopAccess angezeigt.

(2) Wenn mit XPS-Viewer gedruckt wird, w�hrend unter XPS-Druckertreiber der FILE-Port ausgew�hlt ist, erscheint kein Dialogfenster mit dem Dateizielspeicherort, und die Daten k�nnen nicht in einer Datei gespeichert werden. 
* Dieses Ph�nomen tritt unter Windows 7 und Windows Server 2008 R2 nicht auf.

(3) Unter folgenden Umst�nden k�nnen keine �berlagerungsdateien erstellt werden, obwohl �Druck in �berlagerungsdatei� ausgew�hlt und ausgef�hrt wird. 
1. Bei Ausf�hrung mittels Point & Print unter Windows Server und installiertem XPS-Druckertreiber, allerdings nur dann, wenn in der Registerkarte Freigabe nicht �Druckauftragsaufbereitung auf Clientcomputern durchf�hren� ausgew�hlt wurde.
2. Bei Ausf�hrung mit dem automatisch duplizierten XPS-Druckertreiber (Automatisch erstellter Clientdrucker) in der Citrix-Umgebung.

(4) Einige Anwendungen oder Dokumente k�nnen fehlerhafte Druckergebnisse bewirken. Verwenden Sie in diesem Fall den universellen Druckertreiber oder den PS3-Druckertreiber.

(5) Um mithilfe des vom Windows-Server installierten XPS-Druckertreibers mittels Point & Print zu drucken, w�hlen Sie eine Schriftart f�r das Wasserzeichen, das auf dem Server installiert wurde
* Wenn allerdings unter der Registerkarte Freigabe des installierten Druckertreibers �Druckauftragsaufbereitung auf Clientcomputern durchf�hren� ausgew�hlt wird, ist es m�glich, problemlos zu drucken.

(6) Um mithilfe des automatisch duplizierten XPS-Druckertreibers (Auto Created Client Printer) in der Citrix-Umgebung zu drucken, w�hlen Sie f�r das Wasserzeichen eine Schriftart aus, die auf dem Client-PC installiert wurde. Andernfalls kann das Wasserzeichen nicht ordnungsgem�� gedruckt werden.


- Bluetooth
Einige handels�bliche Bluetooth USB-Adapter k�nnen eventuell nicht mit diesem MFP zusammen benutzt werden.
Empfohlene Bluetooth USB-Adapter, entnehmen Sie der Bedienungsanleitung f�r Bluetooth.


--------------------------------------------------------------------------------
Drucken
--------------------------------------------------------------------------------

Regeln
======

1. Manche Dokumente k�nnen bewirken, das der f�r den Druck reservierte Speicher unzureichend wird.

2. Wenn das Drucken mit PS3 im Farbmodus erfolgt, wird der schwarze Toner zum Drucken der grauen Bereiche verwendet, da "Reines Grau" im Dialogfeld "Einstellung" unter "Bildqualit�t" als Standardeinstellung des Druckertreibers aktiviert ist. Infolgedessen kann es zu unerwarteter Ausgabe kommen, abh�ngig von den Druckdaten, (z. B. moir� statt glatter Farbverlauf). Deaktivieren Sie in diesem Fall "Reines Grau."




---------------------------------------------------------
Support-Status der Citrix-Produkte f�r den Druckvorgang
---------------------------------------------------------

1. Namen der unterst�tzten Produkte
  - Citrix Presentation Server 4.5
  - Citrix XenApp 5.0
  - Citrix XenApp 6.0

2. Getestete Betriebsumgebungen
  - Server OS	: Windows Server 2008 SP2, Windows2003 SP2
  - Application	: Citrix XenApp5.0, Citrix Presentation Server 4.5
  - Client OS	: Windows7 SP1, WindowsXP SP3


--------------------------------------------------------------------------------
Warenzeichen
--------------------------------------------------------------------------------

- Der offizielle Name von Windows XP ist Microsoft Windows XP Betriebssystem.
- Der offizielle Name f�r Windows Server 2003 ist Microsoft Windows Server 2003 Operating System.
- Der offizielle Name f�r Windows Server 2008 ist Microsoft Windows Server 2008 Operating System.
- Der offizielle Name von Windows Server 2012 ist "Betriebssystem Microsoft Windows Server 2012".
- Der offizielle Name von Windows Vista ist Microsoft Windows Vista-Betriebssystem.
- Der offizielle Name von Windows 7 ist Microsoft Windows 7-Betriebssystem.
- Der offizielle Name von Windows 8 ist "Betriebssystem Microsoft Windows 8".
- Microsoft, Windows und die Warenzeichen und Produktnamen anderer Microsoft-Produkte sind Warenzeichen der Microsoft Corporation in den USA und anderen L�ndern.
- PostScript und die Warenzeichen und Produktnamen anderer Adobe Systems-Produkte sind Warenzeichen der Adobe Systems Incorporated in den USA und anderen L�ndern.
- Novell, NetWare und NDS sind Warenzeichen von Novell, Inc.
- TopAccess ist ein Warenzeichen von TOSHIBA TEC CORPORATION.
- Citrix, MetaFrame, MetaFrame XP sind eingetragene Marken, und Citrix Presentation Server ist eine Marke von Citrix Systems, Inc. in den USA und/oder anderen L�ndern.
- Bluetooth(R) ist eine registrierte Handelsmarke und Eigentum von Bluetooth SIG, lnc.
- Etwaige bestehende Warenzeichen oder sonstige gewerbliche Schutzrechte an anderen hier zitierten Bezeichnungen erkennen wir an. 
