TOSHIBA e-STUDIO Serie

	Copyright(c) 2003-2012 TOSHIBA TEC CORPORATION Todos derechos reservados 
			7 de diciembre de 2012

Este producto presenta las restricciones y los problemas siguientes. Les recomendamos leer atentamente este manual antes de usar el producto.


--------------------------------------------------------------------------------
Driver de impresora
	para Windows (Universal 2/PS3/XPS)			Versi�n 7.71.2651.1
	para Network-Fax					Versi�n 2.3.65.0
--------------------------------------------------------------------------------

Algunos hechos
==============

1. Windows

- Windows Server 2008, Windows Server 2008 R2 y Windows Server 2012 solo admiten controladores de impresora de tipo universal y PS3.

- Cuando el controlador de impresora instalado en un servidor se instala en un PC cliente mediante la opci�n "Apuntar e imprimir" y se establece el valor predeterminado en [Configuraci�n] de la pesta�a [General] en el controlador de impresora del PC cliente, no se puede reflejar como predeterminada en el PC cliente incluso aunque se modifique [Configuraci�n normal] en el controlador de impresora del servidor.

- Cuando N/W-Fax se utiliza para la transmisi�n FAX y cuando se quiere introducir una pausa en el n�mero que debe componerse, utilice � - � (gui�n).

- En Windows 8 de 32 bits, los cuadros de di�logo que aparecen al imprimir, como "Contrase�a de Impresi�n privada" y "C�digo de departamento", se muestran en un estado inactivo. Esto se debe a que la aplicaci�n se llama a trav�s de WOW64 en Windows 8 de 32 bits. Antes de modificar la configuraci�n, debe activar el cuadro de di�logo.

- Cuando la imagen Retrato (Portrait) y Paisaje (Landscape) existen sobre la misma hoja "Varias P�ginas por hoja", la impresi�n no se efectuar� girando la imagen del una o del otra. Ser� realizada por reducci�n.

- Cuando un papel original que contiene im�genes en orientaci�n vertical y horizontal se imprime en el modo Impresi�n a dos caras, puede que se imprima una imagen en la siguiente p�gina cuando la orientaci�n de alguna de las im�genes cambia.

- El mensaje de ayuda no aparece cuando se hace clic sobre el bot�n "?" en la parte derecha superior de la pantalla.

- Cuando se utiliza el port Standard TCP/IP bajo Windows XP, no cambiar el nombre del port de defecto. Si el nombre del port debe cambiarse, cambiar el nombre, abrir Propriedad del driver de la impresora y cliquear la leng�eta Configuraci�n, luego la tecla Actualizar ahora para localizar e-STUDIO en uso corriente. 

- Cuando la impresi�n se realiza en un ambiente NetWare, la comunicaci�n SNMP no puede realizarse inmediatamente despu�s de que se instale el driver de la impresora. Abrir Propriedad del driver de la impresora y cliquear la leng�eta Configuraci�n, luego la tecla Actualizar ahora para localizar e-STUDIO en uso corriente.

- Cuando se utiliza el driver de impresora PS3 y Adobe Type Manager Font realiza la impresi�n, esto presentar� un error. En este caso, no utilizar Adobe Type Manager Font. Utilizar el driver de impresora PCL cuando se debe utilizar Adobe Type Manager Font.

- Cuando LPR se utiliza para imprimir, invalidar Byte Counting.

- Cuando se imprime una Marca de agua, el resultado podr�a no estar como previsto seg�n los ajustes. En este caso, imprimir nuevamente la Marca de agua despu�s de haber cambiado el tama�o y la posici�n de la Marca de agua. Es eficaz colocar la Marca de agua en la zona imprimible.

- Incompatibilidad con los controladores de impresora TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3 y TOSHIBA e-STUDIO Series XPS

Funciones como �gPerfil�h, �gMarca de agua�h, �gSuperposicion�h y los archivos de configuracion exportados creados con los controladores de impresora TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3 y TOSHIBA e-STUDIO Series XPS no funcionan con este controlador de impresora.
Recreelos con este controlador de impresora.

- Limitacion al usar un perfil
1. <Incompatibilidad entre el modelo equipado con disco duro (HDD) y el modelo no equipado con HDD>
1.1. Cuando se carga un perfil creado por un modelo no equipado con HDD en un modelo equipado con HDD, desaparecen los trabajos de impresion, excepto los de impresion normal e impresion con superposicion.
Cierre la interfaz grafica de usuario del controlador de impresora utilizando la opcion Cancelar y vuelva a abrirla para continuar.

1.2 Cuando se carga un perfil creado por un modelo equipado con HDD en un modelo no equipado con HDD, todos los trabajos de impresion son seleccionables, incluyendo los que requieren HDD.
No seleccione los trabajos de impresion que requieran HDD. Si envia trabajos de impresion que requieren HDD, el trabajo se eliminara en el equipo multifuncion.
Para obtener mas informacion acerca de los trabajos de impresion que requieren HDD, consulte la Guia de impresion.

2. <Incompatibilidad entre el modelo equipado con alimentador automatico de originales con inversion (ADU) y el modelo no equipado con ADU>
2.1. Cuando se carga un perfil creado por un modelo no equipado con ADU en un modelo equipado con ADU, la impresion a doble cara se deshabilita.
Cierre la interfaz grafica de usuario del controlador de impresora utilizando la opcion Cancelar y vuelva a abrirla para continuar.

2.2. Cuando se carga un perfil creado por un modelo equipado con ADU en un modelo no equipado con ADU, la impresion a doble cara se habilita.
  No seleccione la impresion a doble cara. Si envia un trabajo de impresion a doble cara, se imprimira a una sola cara.

- Impresi�n a partir de una aplicaci�n

(1) Visi�n global
Aunque algunas opciones de impresi�n puedan ajustarse a partir de su aplicaci�n, no utilizar su aplicaci�n para ajustar la impresi�n. Utilizar su driver de impresora para ajustar las opciones de impresora.
Cuando la impresi�n se efect�a despu�s del ajuste de su aplicaci�n, se podr�a encontrar con un resultado inesperado o necesitar� un poco de tiempo para el tratamiento.
No ajustar a "Collate" (cotejar) de su aplicaci�n.
Cuando se ajusta un casete de papel de su aplicaci�n, dos "Auto Select tray" pueden ser indicados. En este caso, seleccionar "Auto Select tray" indicado abajo.

(2) Microsoft Excel
Excel procesa cada hoja de trabajo como una tarea de impresi�n. Los ajustes sobre la pantalla del driver de impresora se aplican solamente a la primera hoja de trabajo.

Cuando se entra m�s de una en [Copias] sobre el di�logo de impresi�n para Excel, no puntear en [Cotejar].

(3) Adobe Acrobat 
Cuando se utiliza PS3 para la impresi�n, una im�gen impresa puede ampliarse o reducirse.  En estos casos, la utilizaci�n del PCL6 o la utilizaci�n del PS3 con los siguientes ajustes puede imprimir la imagen a un tama�o adecuado.
Abra el recuadro de di�logo de impresi�n para realizar el ajuste para PS3.
- Seleccionar [Fit to Paper] (Adaptar al papel) a partir del men� [Page Scaling] (Puesta a escala de la p�gina).
- Puntear [Elegir fuente de papel por formato de p�gina PDF].
(Tenga en cuenta que el ajuste de papel del controlador no es v�lido ya que se utiliza el tama�o de papel del archivo PDF.)

(4) Adobe PageMaker
Para impresiones privadas e impresiones de c�digos de departamento que utilizan WindowsPPD para Adobe PageMaker, siempre deber� especificar un c�digo.  De lo contrario, se imprimir� una hoja de error. 


- Point and Print desde el Servidor Windows

(1) La instalaci�n de impresi�n que ha sido ajustada en " Valores predeterminados de impresi�n" del servidor no puede reflejar al lado del cliente seg�n la combinaci�n de SE (Sistema Operativo) del servidor y SE del cliente.

(2) C�mo agregar un controlador de impresora Point & Print (Windows Server - Cliente)
<C�mo agregar un controlador de impresora de 64 � 32 bits en Windows Server 2003 cuando cliente y servidor tienen un tipo de microprocesador distinto>
1. Comparta una impresora en la ficha Compartir del controlador de impresora y haga clic en "Controladores adicionales" para seleccionar x64 o x86.
2. Seleccione un archivo cuya extensi�n sea .INF en el paquete de controladores de impresora (x64 o x86).
3. Se requiere un CD-ROM de la familia Windows Server 2003 (x64/x86). Al insertar el CD se inicia la lectura autom�tica del archivo "NTPRINT.INF" de la carpeta "amd64" o "i386".
4. Dado que se requiere "MSXPSDRV.INF", seleccione "%SYSTEMROOT%\System32\Spool\XPSEP\amd64" o "%SYSTEMROOT%\System32\Spool\XPSEP\i386".
5. (Si el CD cliente utilizado para seleccionar el paquete de controladores en el paso 2 anterior se ha extra�do de la unidad) vuelva a insertar el CD en la unidad y designe la ubicaci�n del controlador de impresora x64 o x86.

<C�mo agregar un controlador de impresora de 64 � 32 bits en Windows Vista, Windows 7, Windows Server 2008 o Windows Server 2008 R2 cuando cliente y servidor tienen un tipo de microprocesador distinto>
[Preparaci�n] Copie la carpeta "ntprint.inf_********" de la carpeta "%SYSTEMROOT%\system32\DriverStore\FileRepository" del cliente de Vista o Windows 7 en el servidor de Vista o Windows 7, o bien permita a los usuarios compartir la carpeta.
1. Comparta una impresora en la ficha Compartir del controlador de impresora y haga clic en "Controladores adicionales" para seleccionar x64 o x86.
2. Seleccione un archivo cuya extensi�n sea .INF en el paquete de controladores de impresora (x64 o x86).
3. Se requieren medios de Windows (procesador x64 o x86). Abra la carpeta "ntprint.inf_********" del cliente de Vista o Windows 7 y seleccione el archivo "ntprint.inf".
4. Haga clic en Aceptar.


- XPS Printer Driver

(1) Cuando la impresi�n se realiza desde el Visor de XPS EP en Windows Vista de 32 � 64 bits utilizando un controlador de impresora XPS, se producen los siguientes problemas. Estos problemas pueden evitarse utilizando un controlador universal o PS3.
1. El c�digo de departamento introducido queda invalidado y el trabajo se trata como un trabajo no definido. 
2. Cuando se realiza una impresi�n privada, la contrase�a introducida en el momento de imprimir queda invalidada y en blanco.
3. La notificaci�n de evento de finalizaci�n de la impresi�n no se env�a desde TopAccessDocMon.
4. La cola de trabajo no puede imprimirse o eliminarse de TopAccessDocMon.
5. El nombre del documento no se muestra en el panel t�ctil del equipo y la cola de impresi�n de TopAccessDocMon, as� como el registro de impresi�n y las pantallas de e-Filing de TopAccess.

(2) Si la impresi�n se realiza en el Visor de XPS mientras est� seleccionado el puerto FILE del controlador de impresora XPS, el cuadro de di�logo de ruta de destino de archivos no aparece, y los datos no pueden almacenarse en un archivo.
* Este fen�meno no se produce en Windows 7 y Windows Server 2008 R2.

(3) En las siguientes circunstancias no pueden crearse archivos de superposici�n, incluso aunque se seleccione y ejecute "Impr. en arch. superpos.". 
1. Al ejecutar con un controlador de impresora XPS instalado mediante Point & Print en Windows Server, pero solo cuando "Procesar trabajos de impresi�n en equipos cliente" no est� seleccionado en la ficha Compartir del controlador de impresora instalado.
2. Al ejecutar con el controlador de impresora XPS duplicado autom�ticamente (Auto Created Client Printer) en el entorno Citrix.

(4) Algunas aplicaciones o documentos pueden producir copias impresas incorrectas. En tal caso, utilice el controlador de impresora universal o PS3.

(5) Para imprimir utilizando el controlador de impresora XPS instalado desde Windows Server mediante Point & Print, seleccione una fuente para la marca de agua que se haya instalado en el servidor.
* No obstante, si "Procesar trabajos de impresi�n en equipos cliente" est� seleccionado en la ficha Compartir del controlador de impresora instalado, la impresi�n puede realizarse correctamente.

(6) Para imprimir utilizando el controlador de impresora XPS duplicado autom�ticamente (Auto Created Client Printer) en un entorno Citrix, seleccione una fuente para la marca de agua, que se ha instalado en un PC cliente. En caso contrario, la marca de agua no se podr� imprimir correctamente.


- Bluetooth
Algunos adaptadores Bluetooth USB disponibles en el mercado podr�an no funcionar con este MFP.
Para conocer los adaptadores Bluetooth USB recomendados, consulte el manual de funcionamiento de Bluetooth.


--------------------------------------------------------------------------------
Impresi�n
--------------------------------------------------------------------------------

Algunos hechos
==============

1. Algunos documentos podr�an causar una insuficiencia de impresi�n de la memoria destinada a la impresi�n.

2. Cuando se imprime con la PS3 en modo de color, el t�ner negro se utiliza para imprimir las �reas grises, porque la opci�n "Gris puro" est� activada en el di�logo "Configuraci�n" bajo "Calidad de imagen" como valor predeterminado del controlador de impresora. Como resultado, puede producirse una impresi�n inesperada seg�n los datos de impresi�n (por ejemplo, moir� en lugar de una gradaci�n uniforme). En este caso, desactive la opci�n "Gris puro."




---------------------------------------------------------
Compatibilidad de los productos Citrix para imprimir
---------------------------------------------------------

1. Nombres de productos compatibles
  - Citrix Presentation Server 4.5
  - Citrix XenApp 5.0
  - Citrix XenApp 6.0

2. Sistemas operativos verificados
  - Server OS	: Windows Server 2008 SP2, Windows2003 SP2
  - Application	: Citrix XenApp5.0, Citrix Presentation Server 4.5
  - Client OS	: Windows7 SP1, WindowsXP SP3


--------------------------------------------------------------------------------
Marcas registradas
--------------------------------------------------------------------------------

- El nombre oficial de Windows XP es "Microsoft Windows XP Operating System" (Sistema Operativo de Windows XP de Microsoft).
- El nombre oficial de Windows Server 2003 es "Microsoft Windows Server 2003 Operating System" (Sistema Operativo de Windows Server 2003 de Microsoft).
- El nombre oficial de Windows Server 2008 es "Microsoft Windows Server 2008 Operating System" (Sistema Operativo de Windows Server 2008 de Microsoft).
- El nombre oficial de Windows Server 2012 es Sistema operativo Microsoft Windows Server 2012.
- El nombre oficial de Windows Vista es Sistema operativo Microsoft Windows Vista.
- El nombre oficial de Windows 7 es Sistema operativo Microsoft Windows 7.
- El nombre oficial de Windows 8 es Sistema operativo Microsoft Windows 8.
- Microsoft, Windows y las marcas de f�brica y otros productos Microsoft representan las marcas registradas de Microsoft Corporation en los Estados Unidos y otros pa�ses.
- PostScript y las marcas de f�brica y otros productos Adobe Systems representan las marcas registradas de Adobe Systems Incorporated en los Estados Unidos y otros pa�ses.
- Novell, NetWare y NDS son las marcas registradas de Novell, Inc.
- TopAccess es una marca registrada de TOSHIBA TEC CORPORATION.
- Citrix, MetaFrame, MetaFrame XP son marcas registradas, y Citrix Presentation Server es marca comerciale de Citrix Systems, Inc. en EEUU y en otros pa�ses.
- Bluetooth(R) es una marca comercial registrada propiedad de Bluetooth SIG, lnc.
- Los otros nombres de compa��as y nombres de productos mencionados en este manual son las marcas registradas de sus compa��as respectivas.
