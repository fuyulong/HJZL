TOSHIBA e-STUDIO Serie

	Copyright(c) 2003-2012 TOSHIBA TEC CORPORATION Ogni diritto riservato
			7 dicembre 2012

Questo prodotto presenta le restrizioni e problemi seguenti. Vi raccomandiamo di leggere attentamente questo manuale prima di utilizzare il prodotto.


--------------------------------------------------------------------------------
Driver di stampa
	per Windows (Universal 2/PS3/XPS)			Versione 7.71.2651.1
	per Network-Fax						Versione 2.3.65.0
--------------------------------------------------------------------------------

Problemi
========

1. Windows

- Windows Server 2008, Windows Server 2008 R2 e Windows Server 2012 supportano solo il driver della stampante universale e PS3.

- Quando il driver della stampante installato su un server viene installato su un client PC utilizzando "Seleziona e stampa" e il valore predefinito � impostato su [Impostazioni] nella scheda [Generale] nel driver della stampante nel client PC, questo non pu� essere applicato sul client PC anche se le [Impostazioni normali] vengono modificate nel driver della stampante del server.

- Se per la trasmissione FAX si fa uso di N/W-Fax e si desidera inoltre inserire una pausa nella composizione del numero, utilizzare il trattino � - �.

- In Windows 8 a 32 bit, le finestre di dialogo sono visualizzate durante la stampa, ad esempio: "Password Stampa riservata" e "Codice reparto" sono visualizzate con stato inattivo. Questo si verifica perch� l'applicazione viene invocata tramite WOW64 in Windows 8 a 32 bit. Rendere attiva la finestra di dialogo visualizzata prima dell'impostazione.

- Quando l'immagine Ritratto (Portrait) e Paesaggio (Landscape) esistono sullo stesso foglio "Pagine multiple per foglio", la stampa non sar� effettuata girando l'immagine dell'uno o dell'altro. Sar� effettuata con riduzione.

- eCopy sowie die Marken- und Produktnamen eCopy-zugeh�riger Produkte sind in den Vereinigten Staaten und anderen L�ndern Marken oder eingetragene Marken von eCopy.

- Il messaggio d'aiuto non appare anche quando si fa clic sul tasto "?"  sulla parte destra superiore dello schermo.

- In caso di utilizzo della porta Standard TCP/IP in ambiente Windows XP, non modificate il nome predefinito della porta.  Qualora esso debba essere modificato, procedete con la modifica, aprite la finestra Propriet� del driver di stampa, cliccate sul selettore Configurazione e quindi sul pulsante Aggiorna adesso in modo da individuare l'e-STUDIO attualmente in uso.

- In caso di stampa in ambiente NetWare non � possibile eseguire la comunicazione SNMP immediatamente dopo avere installato il driver di stampa.  Aprite la finestra Propriet� del driver di stampa, cliccate sul selettore Configurazione e quindi sul pulsante Aggiorna adesso in modo da individuare l'e-STUDIO attualmente in uso.

- Quando il driver della stampante PS3 � utilizzato ed Adobe Type Manager Font effettua la stampa, questo presenter� un errore. In questo caso, non utilizzare Adobe Type Manager Font. Utilizzare il driver di stampante PCL quando si deve utilizzare Adobe Type Manager Font.

- In caso di stampa con LPR, disabilitate il conteggio di byte.

- In caso di stampa di una Filigrana, in funzione delle impostazioni eseguite il risultato potrebbe differire da quello atteso. In tal caso stampate nuovamente la Filigrana dopo avere modificato in Filigrana il formato e la posizione.  Si rivela efficace posizionare la Filigrana nell'area stampabile.

- Incompatibilita con TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3 e un driver di stampa TOSHIBA e-STUDIO Series XPS

Le funzioni come "Profilo", "Filigrana", "Sovrapposizione" e i file di impostazione esportati creati con i driver di stampa di TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3, TOSHIBA e-STUDIO Series XPS non sono operativi con questo driver.
E necessario ricrearli mediante questo driver.

- Limitazione per l'uso della funzione Profilo
1. <Incompatibilita tra il modello dotato di disco rigido (HDD) e il modello privo di disco rigido>
1.1. Caricando in un modello dotato di disco rigido un Profilo creato mediante un modello privo di disco rigido, non saranno visibili i lavori di stampa, ad eccezione della stampa normale e della stampa in sovrapposizione.
Premere Annulla per chiudere l'interfaccia grafica del driver di stampa, quindi riaprire per continuare.

1.2 Caricando un Profilo creato mediante un modello dotato di disco rigido in un modello privo di disco rigido, saranno selezionabili tutti i lavori di stampa, compresi quelli che richiedono il disco rigido.
Non selezionare i lavori di stampa che richiedono il disco rigido. Se si invia un lavoro di stampa che richiede il disco rigido, tale lavoro verra eliminato nell'MFP.
Per i dettagli sui lavori di stampa che richiedono il disco rigido, fare riferimento alla Guida alla stampa.

2. <Incompatibilita tra i modelli dotati di modulo fronte/retro automatico (ADU) e i modelli che ne sono privi>
2.1. Caricando in un modello dotato di modulo fronte/retro automatico un Profilo creato mediante un modello privo di tale modulo, verra disabilitata la stampa fronte/retro.
Premere Annulla per chiudere l'interfaccia grafica del driver di stampa, quindi riaprire per continuare.

2.2. Caricando in un modello privo di modulo fronte/retro automatico un Profilo creato mediante un modello dotato di tale modulo, verra abilitata la stampa fronte/retro.
  Non selezionare Stampa fronte/retro. Se si invia un lavoro di stampa fronte/retro, quest'ultimo verra stampato su lato singolo.

- Stampa a partire da un'applicazione

(1) Veduta d'insieme	
Bench� alcune opzioni di stampa possano essere impostate a partire dalla vostra applicazione, non utilizzare la vostra applicazione per impostare la stampa. Utilizzare il vostro driver di stampante per impostare delle opzioni di stampante.
Quando la stampa viene effettuata dopo impostazione della vostra applicazione, si potrebbe ritrovarsi con un risultato inatteso o ci� potr� necessitare un p� di tempo per il trattamento.
Non impostare "Collate" (Raccogliere) della vostra applicazione.
Quando si imposta uno scomparto di carta della vostra applicazione, due "Auto Select tray" possono essere visualizzati. In questo caso, scegliere "Auto Select tray" visualizzato sotto.

(2) Microsoft Excel
Excel gestisce ciascun foglio di lavoro come un'unica operazione di stampa.  Le impostazioni eseguite nello schermo del driver di stampa sono pertanto valide solamente per il primo foglio di lavoro.

Quando nel campo [Copie] del dialogo di stampa di Excel si inserisce un valore superiore a 1, non si deve selezionare la casella [Fascicola].

(3) Adobe Acrobat 
Se si stampa con il PS3, l'immagine pu� apparire ingrandita oppure ridotta.  In tal caso, stampando con il PCL6 oppure con il PS3 usando le impostazioni qui di seguito indicate, l'immagine pu� essere stampata nel formato corretto.
Aprite il dialogo Stampa in modo da eseguire l'impostazione del PS3.
- Dal menu [Ridimensionamento pagina] selezionate [Adatta alla carta].
- Selezionate la casella [Scegli alimentazione da dimensioni pagina PDF].
(Vi preghiamo di notare che l'impostazione della carta nel driver non � valida poich� si utilizza il formato del file PDF.)

(4) Adobe PageMaker
Per la stampa personale e la stampa del codice reparto con WIndowsPPD per Adobe PageMaker, � necessario specificare sempre il codice.  Altrimenti, verr� stampato un foglio d'errore. 


- Point and print dal Server Windows

(1) La messa a punto della stampa che � stata regolata in "Predefinite)" del Server non pu� riflettere al lato del cliente secondo la combinazione del SO (Sistema Operativo) del Server e del SO del cliente.

(2) Come aggiungere il driver di una stampante Point & Print (Client/server Windows)
<Come aggiungere il driver di una stampante a 64 bit o a 32 bit in Windows Server 2003 se il tipo di microprocessore cambia tra il client e il server>
1. Condividere una stampante nella scheda Condivisione del driver della stampante e fare clic su "Driver aggiuntivi" per selezionare x64 o x86.
2. Selezionare un file con estensione .INF dal pacchetto driver (x64 o x86) della stampante.
3. � necessario un CD-ROM della famiglia Windows Server 2003 (x64/x86).  Inserendo il CD viene automaticamente avviata la lettura di "NTPRINT.INF" dalla cartella "amd64" o "i386".
4. Poich� � necessario "MSXPSDRV.INF", selezionare "%SYSTEMROOT%\System32\Spool\XPSEP\amd64" o "%SYSTEMROOT%\System32\Spool\XPSEP\i386."
5. (Se il CD client utilizzato per selezionare il pacchetto driver al precedente punto 2 � stato rimosso dall�unit�) inserire nuovamente il CD nell�unit� e scegliere la posizione del driver della stampante tra x64 o x86.

<Come aggiungere il driver di una stampante a 64 bit o a 32 bit in Windows Vista, Windows 7, Windows Server 2008 o Windows Server 2008 R2 se il tipo di microprocessore cambia tra il client e il server>
[Operazioni preliminari] Copiare la cartella "ntprint.inf_********" nella cartella "%SYSTEMROOT%\system32\DriverStore\FileRepository" del client Vista o Windows 7 sul server Vista o Windows 7, o consentire agli utenti di condividere la cartella.
1. Condividere una stampante nella scheda Condivisione del driver della stampante e fare clic su "Driver aggiuntivi" per selezionare x64 o x86.
2. Selezionare un file con estensione .INF dal pacchetto driver (x64 o x86) della stampante.
3. � necessario Windows media (processore x64) o Windows media (processore x86).  Aprire la cartella "ntprint.inf_********" del client Vista o Windows 7 e selezionare il file "ntprint.inf".
4. Fare clic su OK.


- XPS Printer Driver

(1) Se la stampa viene eseguita da XPS Viewer EP di Windows Vista 32bit, o XPS Viewer EP di Windows Vista 64bit tramite driver di una stampante XPS, si verifica il problema riportato di seguito. Utilizzando un driver universale o un driver PS3 � possibile evitare questi problemi.
1. Il codice di reparto inserito non � pi� valido e il processo viene considerato un processo indefinito. 
2. Se viene eseguita una stampa privata, la password immessa all�atto della stampa non � pi� valida e non viene specificata.
3. TopAccessDocMon non invia la notifica evento di completamento della stampa.
4. Non � possibile stampare o eliminare da TopAccessDocMon la coda dei processi di stampa.
5. Il nome del documento non viene visualizzato sul pannello a sfioramento dell�apparecchio, sulla coda di stampa di TopAccessDocMon, sul registro di stampa e sulle schermate e-Filing di TopAccess.

(2) Se la stampa viene eseguita su XPS Viewer mentre la porta FILE viene selezionata dal Driver della stampante XPS, non viene visualizzata la finestra di dialogo del percorso di destinazione del file e non � possibile memorizzare i dati in un file. 
* Con Windows 7 e Windows Server 2008 R2, questo non accade.

(3) Pur avendo selezionato ed eseguito la funzione "Stampa su modulo elettronico", nelle circostanze riportate di seguito non � possibile creare moduli elettronici. 
1. Durante l�esecuzione con il Driver della stampante XPS installato tramite la funzione Point & Print di Windows Server, ma solo se nella scheda Condivisione del driver della stampante installato non viene selezionata la voce "Esegui rendering dei processi di stampa nei computer client".
2. Durante l�esecuzione con il Driver della stampante XPS automaticamente duplicato (Auto Created Client Printer �Stampante client creata automaticamente) in ambiente Citrix.

(4) Alcune applicazioni o documenti potrebbero compromettere la corretta esecuzione della stampa.  In tal caso, utilizzare il driver della stampante universale o PS3.

(5)  Per stampare tramite il driver della stampante XPS installato dal server Windows da Point & Print, selezionare un carattere per la filigrana installato sul server.
* Tuttavia, se � stata selezionata la funzione "Esegui rendering dei processi di stampa nei computer client" nella scheda Condivisione del driver della stampante installato, � possibile che l�operazione di stampa venga eseguita correttamente.

(6) Per stampare utilizzando il driver della stampante XPS duplicato automaticamente (Auto Created Client Printer) in ambiente Citrix, selezionare un carattere per la filigrana installato su un computer client. In caso contrario, la filigrana non pu� essere stampata correttamente.


- Bluetooth
Alcuni adattatori di Bluetooth USB disponibili in commercio non possono essere utilizzati con questo MFP.
Per gli adattatori di Bluetooth USB disponibili, fare riferimento al manuale operativo per il Bluetooth.


--------------------------------------------------------------------------------
Stampa
--------------------------------------------------------------------------------

Problemi
========

1. Alcuni documenti potrebbero rendere insufficiente la memoria destinata alle operazioni di stampa.

2. Quando si esegue la stampa con il PS3 in modalit� a colori, il toner nero viene utilizzato per stampare le aree grigie, poich� la funzione "Grigio puro" � impostata su ON nella finestra di dialogo "Impostazione" sotto "Qualit� immagine" come impostazione predefinita del driver di stampa. Di conseguenza, la stampa prodotta potrebbe presentare un risultato imprevisto a seconda dei dati da stampare (ad esempio, un effetto moir� anzich� una gradazione omogenea). In questo caso, impostare "Grigio puro" su OFF.





---------------------------------------------------------
Stato del supporto dei prodotti Citrix per la stampa
---------------------------------------------------------

1. Nomi dei prodotti supportati
  - Citrix Presentation Server 4.5
  - Citrix XenApp 5.0
  - Citrix XenApp 6.0

2. Ambienti operativi verificati
  - Server OS	: Windows Server 2008 SP2, Windows2003 SP2
  - Application	: Citrix XenApp5.0, Citrix Presentation Server 4.5
  - Client OS	: Windows7 SP1, WindowsXP SP3


--------------------------------------------------------------------------------
Marca depositata
--------------------------------------------------------------------------------

- Il nome ufficiale di Windows XP � "Microsoft Windows XP Operating System" (Sistema operativo di Windows XP di Microsoft).
- Il nome ufficiale di Windows Server 2003 � "Microsoft Windows Server 2003 Operating System" (Sistema operativo di Windows Server 2003 di Microsoft).
- Il nome ufficiale di Windows Server 2008 � "Microsoft Windows Server 2008 Operating System" (Sistema operativo di Windows Server 2008 di Microsoft).
- Il nome ufficiale di Windows Server 2012 � Sistema operativo Microsoft Windows Server 2012.
- Il nome ufficiale di Windows Vista � Sistema operativo Microsoft Windows Vista.
- Il nome ufficiale di Windows 7 � Sistema operativo Microsoft Windows 7.
- Il nome ufficiale di Windows 8 � Sistema operativo Microsoft Windows 8.
- Microsoft, Windows ed i marchi di fabbrica e di altri prodotti Microsoft rappresentano le marche depositate di Microsoft Corporation negli Stati Uniti ed altri paesi.	
- PostScript ed i marchi di fabbrica e di altri prodotti Adobe Systems rappresentano le marche depositate di Adobe Systems Incorporated negli Stati Uniti ed altri paesi.	
- Novell, NetWare, e NDS sono le marche depositate di Novell, Inc.
- TopAccess � un marca depositata di TOSHIBA TEC CORPORATION.
- Citrix, MetaFrame, MetaFrame XP sono marchi registrati e Citrix Presentation Server � un marchio della Citrix Systems, Inc. negli Stati Uniti e in altre nazioni.
- Bluetooth(R) est une marque d�pos�e de la Bluetooth SIG, lnc.
- Gli altri nomi di societ� e nomi di prodotti citati in questo manuale sono le marche depositate delle loro societ� rispettive.
