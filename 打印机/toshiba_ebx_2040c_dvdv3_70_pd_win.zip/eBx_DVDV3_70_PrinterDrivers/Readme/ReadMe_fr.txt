TOSHIBA e-STUDIO S�rie

	Copyright(c) 2003-2012 TOSHIBA TEC CORPORATION Tous droits r�serv�s
			7 d�cembre, 2012

Ce produit pr�sente les restrictions et probl�mes suivants.  Nous vous recommandons de lire attentivement ce manuel avant l'utilisation du produit.


--------------------------------------------------------------------------------
Pilote d'imprimante
	pour Windows (Universal 2/PS3/XPS)	     		Version 7.71.2651.1
	pour Network-Fax				     	Version 2.3.65.0
--------------------------------------------------------------------------------

Certains faits
==============

1. Windows

- Windows Server 2008, Windows Server 2008 R2 et Windows Server 2012 prennent en charge le pilote d'imprimante universel et PS3.

- Lorsqu'un pilote d'imprimante install� sur un serveur est install� sur un ordinateur client � l'aide de "Pointer et imprimer" et que la valeur par d�faut est r�gl�e sur [Param�tres] sur l'onglet [G�n�ral] dans le pilote d'imprimante de l'ordinateur client, il ne peut pas �tre le pilote par d�faut dans l'ordinateur client m�me si l'option [Param�tres normaux] est modifi� dans le pilote d'imprimante du serveur.

- Quand N/W-Fax est utilis� pour la transmission FAX et quand on veut introduire une pause dans le num�ro � composer, utiliser � � � (tiret).

- Sous Windows 8 32 bits, les bo�tes de dialogue apparaissaient � l'impression, par ex., "Mot de passe d'impression priv�e" et "Code d�partemental", s'affichent � l'�tat inactif. La raison : l'application est appel�e via WOW64 sous Windows 8 32 bits. Veuillez vous assurer d'activer la bo�te de dialogue avant le param�tre.

- Lorsque l'image Portrait et Paysage (Landscape) existent sur la m�me feuille "Plusieurs pages par feuille" , l'impression ne sera pas effectu�e en tournant l'image de l'une ou de l'autre.  Elle sera ex�cut�e par r�duction.

- Lorsqu'une feuille de papier original contenant des images Portrait et Paysage est imprim�e en mode Impression recto-verso, il se peut qu'une image s'imprime sur la page suivante lorsque l'orientation de l'image change.

- Le message d'aide n'appara�t pas m�me lorsque l'on fait clic sur le bouton "?" sur la partie droite sup�rieure de l'�cran.

- Quand on utilise le port Standard TCP/IP sous Windows XP, ne pas changer le nom du port de d�faut. Si le nom du port doit �tre chang�, changer le nom, ouvrir Propri�t� du pilote de l'imprimante et cliquer sur la languette Configuration, puis sur la touche Mettre � jour maintenant pour localiser e-STUDIO en usage courant. 

- Quand l'impression est ex�cut�e dans un environnement NetWare, la communication SNMP ne peut pas �tre ex�cut�e juste apr�s que le pilote de l'imprimante est install�. Ouvrir Propri�t� du pilote de l'imprimante et faire clic sur l'onglet de Configuration, puis sur la touche Mettre � jour maintenant pour localiser e-STUDIO en usage courant.

- Lorsque le pilote d'imprimante PS3 est utilis� et Adobe TypeManager Font ex�cute l'impression, ceci pr�sentera une erreur. Dans ce cas, ne pas utiliser Adobe TypeManager Font.  Utiliser le pilote d'imprimante PCL lorsque on doit utiliser Adobe TypeManager Font.

- Lorsque LPR est utilis� pour imprimer, invalider Byte Counting.

- Quand on imprime un Filigrane, le r�sultat pourrait ne pas �tre comme pr�vu selon les r�glages. Dans ce cas, imprimer de nouveau le Filigrane apr�s avoir chang� la dimension et la position du Filigrane.  Il est efficace de positionner le Filigrane dans la zone imprimable.

- Incompatible avec TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3, et un pilote d'imprimante TOSHIBA e-STUDIO Series XPS

Les caracteristiques telles que �� Profil ��, �� Tatouage numerique ��, �� Recouvrement ��, les fichiers de parametrage exportes crees avec les pilotes d'imprimante TOSHIBA Universal Printer, TOSHIBA e-STUDIO Series PS3, TOSHIBA e-STUDIO Series XPS ne fonctionnent pas avec ce pilote d�fimprimante.
Recreez-les avec ce pilote d�fimprimante.

- Limitation lors de l'utilisation de Profil
1. <Incompatibilite entre le modele equipe de disque dur (HDD) et le modele non equipe de disque dur>
1.1. Lorsque vous chargez un profil cree avec un modele non equipe de disque dur sur un modele equipe de disque dur, les travaux d'impression, excepte l�fimpression normale et l�fimpression par recouvrement, disparaissent.
Fermez le pilote d'imprimante GUI via Annuler et rouvrez-le pour continuer.

1.2 Lorsque vous chargez un profil cree par un modele equipe de disque dur sur un modele non equipe de disque dur, tous les travaux d'impression, y compris ceux requerrant un disque dur, peuvent etre selectionnes.
Ne selectionnez pas les travaux d'impression requerrant un disque dur. Si vous envoyez un travail d'impression requerrant un disque dur, le travail sera supprime dans le peripherique multifonction.
Pour plus d'informations sur les travaux d'impression requerrant un disque dur, reportez-vous au manuel d'impression.

2. <Incompatibilite entre le modele equipe d'appareil de duplexage automatique (ADU) et le modele non equipe d'appareil de duplexage automatique>
2.1. Lorsque vous chargez un profil cree par un modele non equipe d'ADU sur un modele equipe d'ADU, l'impression sur les deux faces est desactivee.
Fermez le pilote d'imprimante GUI via Annuler et le rouvrir pour continuer.

2.2. Lorsque vous chargez un profil cree par un modele equipe d'ADU sur un modele non equipe d'ADU, l'impression sur les deux faces est activee.
  Ne selectionnez pas l'impression sur les deux faces. Si vous envoyez un travail d'impression sur les deux faces, il sera imprime sur une seule face.

- Impression � partir d'une application

(1) Vue d'ensemble
Bien que certaines options d'impression puissent �tre r�gl�es � partir de votre application, ne pas utiliser votre application pour r�gler l'impression.  Utiliser votre pilote d'imprimante pour r�gler des options d'imprimante.
Lorsque l'impression est effectu�e apr�s r�glage de votre application, on pourrait se retrouvez avec un r�sultat inattendu ou cela pourra prendre un bon moment pour le traitement.
Ne pas r�gler "Collate" (Recueillir) de votre application.
Lorsque l'on r�gle un magasin de papier de votre application, deux "Auto Select tray" peuvent �tre affich�s.  Dans ce cas, s�lectionner "AutoSelect tray" affich� dessous.

(2) Microsoft Excel
Excel traite chaque  feuille de travail comme une t�che d'impression. Les r�glages sur l'�cran du pilote d'imprimante s'appliquent seulement � la premi�re feuille de travail.

Quand on entre plus d'une dans [Copies] sur le dialogue d'impression pour Excel, ne pas cocher [Assembler].

(3) Adobe Acrobat 
Lors de l'impression, si PS3 est utilis�, il peut se peut que l'image imprim�e soit agrandie ou r�duite. Dans ce cas, l'utilisation de PCL6 or bien encore de PS3 avec les configurations suivantes permet une impression de dimensions correctes.
Ouvrir la bo�te de dialogue "impression" pour r�aliser les r�glages de PS3.
- S�lectionner [Adapter au papier] � partir du menu [Mise � l'�chelle de la page].
- Cocher [Choisir source de papier par format de page PDF].
(Noter que la configuration du papier du pilote est invalide tant le format papier du fichier pdf est utilis�.)

(4) Adobe PageMaker
Pour l'impression priv�e et l'impression de code de d�partement avec WIndowsPPD pour Adobe PageMaker, sp�cifiez toujours un code.  Autrement une feuille d'erreur sera imprim�e. 


- Point and print � partir du Serveur Windows

(1) L'installation d'impression qui a �t� r�gl� dans "Impression par d�faut" du serveur ne peut pas r�fl�ter au c�t� du client selon la combinaison du SE (Syst�me d'Exploitation) du serveur et du SE du client. 

(2) Comment ajouter un pilote d�impression Point & Print (Windows Server - Client)
<Comment ajouter un pilote d�impression de 64 ou 32 bits sous Windows Server 2003 lorsque le type de processeur du client et celui du serveur sont diff�rents>
1. Mettez en commun une imprimante dans l�onglet Partage du pilote d�imprimante et cliquez sur Pilotes suppl�mentaires pour s�lectionner x64 ou x86.
2. S�lectionnez un fichier dont l�extension est .INF sur le progiciel de pilote d�imprimante (x64 ou x86).
3. Un CD-ROM famille Windows Server 2003 (x64/x86) est requis. L�insertion du CD-ROM lance automatiquement la lecture de � NTPRINT.INF � depuis le dossier � amd64 � ou � i386 �.
4. �tant donn� que � MSXPSDRV.INF � est requis, s�lectionnez � %SYSTEMROOT%\System32\Spool\XPSEP\amd64 � ou � %SYSTEMROOT%\System32\Spool\XPSEP\i386 �.
5. (Si le CD-ROM client utilis� pour s�lectionner le progiciel pilote � l��tape 2 ci-dessus a �t� retir� du lecteur) ins�rez � nouveau le CD-ROM dans le lecteur et indiquez l�emplacement de pilote d�imprimante x64 ou x86.

<Comment ajouter un pilote d�impression de 64 ou 32 bits sous Windows Vista, Windows 7, Windows Server 2008 ou Windows Server 2008 R2 lorsque le type de processeur du client et celui du serveur sont diff�rents>
[Pr�paration] Copiez le dossier � ntprint.inf_******** � dans le dossier � %SYSTEMROOT%\system32\DriverStore\FileRepository � sous Vista ou Windows 7 client vers le serveur Vista ou Windows 7 ou autoriser les utilisateurs � mettre le dossier en commun.
1. Mettez en commun une imprimante dans l�onglet Partage du pilote d�imprimante et cliquez sur � Pilotes suppl�mentaires � pour s�lectionner x64 ou x86.
2. S�lectionnez un fichier dont l�extension est .INF dans le progiciel de pilote d�imprimante (x64 ou x86).
3. Windows media (processeur x64) ou Windows media (processeur x86) sont requis.  Ouvrez le dossier � ntprint.inf_******** � dans client Vista ou Windows 7 et s�lectionnez le fichier � ntprint.inf �.
4. Cliquez sur OK.


- XPS Printer Driver

(1) Lorsque l�impression est ex�cut�e � partir de Visionneuse XPS EP sous Windows Vista 32 bits ou Visionneuse XPS EP sous Windows Vista 64 bits avec un pilote d�imprimante XPS, les probl�mes suivants apparaissent. Ces probl�mes peuvent �tre �vit�s avec un pilote universel ou PS3.
1. Le code de d�partement saisi devient invalide et la t�che est trait�e comme t�che ind�finie.
2. En cas d�impression par un particulier, le mot de passe saisi au moment de l�impression devient invalide et vide.
3. La notification d��v�nement pour terminer l�impression n�est pas envoy�e depuis TopAccessDocMon.
4. La file d�attente des t�ches ne peut pas �tre imprim�e ou supprim�e depuis TopAccessDocMon.
5. Le nom de document n�est pas affich� sur le panneau tactile de l��quipement, la file d�attente d�impression dans TopAccessDocMon et le journal d�impression et les �crans d�e-archivage dans TopAccess.

(2) Lors de l�impression en Visionneuse XPS alors que le port FICHIER est s�lectionn� sous pilote d�imprimante XPS, la fen�tre de dialogue du chemin de destination fichier n�appara�t pas et les donn�es ne peuvent pas �tre stock�es dans un fichier. 
* Ce ph�nom�ne ne se produit pas sous Windows 7 et Windows Server 2008 R2.

(3) Il n�est pas possible de cr�er de fichiers de surimpression dans les circonstances suivantes, m�me si � Cr�er fichier de surimpression � est s�lectionn� et ex�cut�. 
1. Lors d'une ex�cution avec le pilote d�impression XPS install�, en utilisant Point & Print sous Windows Server, uniquement lorsque � Rendu des travaux d'impression sur les ordinateurs client � n�est pas s�lectionn� dans l�onglet Partage du pilote d�impression install�.
2. Lors d�une ex�cution avec le pilote d�impression XPS automatiquement reproduit (Impression client cr��e automatiquement) sous Citrix.

(4) Certaines applications ou certains documents pourraient produire de mauvaises impressions. Utilisez le pilote d�impression universel ou PS3 si cela se produit.

(5) Pour imprimer � l�aide du pilote d�imprimante XPS install� depuis le serveur Windows par Point & Print, s�lectionnez une police de caract�re comme filigrane num�rique, install�e sur le serveur.
* Toutefois, si � Rendu des travaux d'impression sur les ordinateurs client � est s�lectionn� dans l�onglet Partage du pilote d�imprimante install�, il est possible d�effectuer une impression correcte.

(6) Pour imprimer avec le pilote d'imprimante XPS (Auto Created Client Printer) copi� automatiquement dans l'environnement Citrix, s�lectionnez une police de filigrane install�e sur un ordinateur client. Sinon, le filigrane ne s'imprime pas correctement.


- Bluetooth
Certains adaptateurs Bluetooth USB disponibles dans le commerce risquent de ne pas pouvoir s'utiliser avec ce MFP.
Pour en savoir plus sur les adaptateurs Bluetooth USB recommand�s, consultez le manuel d'utilisation de Bluetooth.


--------------------------------------------------------------------------------
Impression
--------------------------------------------------------------------------------

Certains faits
==============

1. Certains documents pourraient causer une insuffisance d'impression de la m�moire affect�e � l'impression.

2. Si vous imprimez avec le PS3 en mode couleur, l'encre noire est utilis�e pour imprimer les zones grises puisque "Gris int�gral" est r�gl� sur ON dans la bo�te de dialogue "Param�trage" sous "Qualit� d'image" comme r�glage par d�faut du pilote d'imprimante. Par cons�quent, il se peut que le r�sultat de l'impression ne soit pas celui escompt� avec certaines donn�es (par exemple du moir� au lieu d'une gradation douce). Dans ce cas, r�glez "Gris int�gral" sur OFF.





---------------------------------------------------------
�tat de prise en charge d'appareil Citrix pour impression
---------------------------------------------------------

1. Noms des appareils pris en charge
  - Citrix Presentation Server 4.5
  - Citrix XenApp 5.0
  - Citrix XenApp 6.0

2. Environnements d'exploitation confirm�s
  - Server OS	: Windows Server 2008 SP2, Windows2003 SP2
  - Application	: Citrix XenApp5.0, Citrix Presentation Server 4.5
  - Client OS	: Windows7 SP1, WindowsXP SP3


--------------------------------------------------------------------------------
Marques d�pos�es
--------------------------------------------------------------------------------

- Le nom officiel de Windows XP est "Microsoft Windows XP Operating System" (Logiciel d'exploitation de Windows XP de Microsoft).
- Le nom officiel de Windows Server 2003 est "Microsoft Windows Server 2003 Operating System" (Logiciel d'exploitation de Windows Server 2003 de Microsoft).
- Le nom officiel de Windows Server 2008 est "Microsoft Windows Server 2008 Operating System" (Logiciel d'exploitation de Windows Server 2008 de Microsoft).
- Le nom officiel de Windows Server 2012 est Syst�me d'exploitation Microsoft Windows Server 2012.
- Le nom officiel de Windows Vista est Syst�me d'exploitation Microsoft Windows Vista.
- Le nom officiel de Windows 7 est Syst�me d'exploitation Microsoft Windows 7.
- Le nom officiel de Windows 8 est Syst�me d'exploitation Microsoft Windows 8.
- Microsoft, Windows et les marques de fabrique et d'autres produits Microsoft repr�sentent les marques d�pos�es de Microsoft Corporation aux �tats-Unis et autres pays.
- PostScript et les marques de fabrique et d'autres produits Adobe Systems repr�sentent les marques d�pos�es de Adobe Systems Incorporated aux �tats-Unis et autres pays.
- Novell, NetWare, et NDS sont les marques d�pos�es de Novell, Inc.
- TopAccess est une marque d�pos�e de TOSHIBA TEC CORPORATION.
- Citrix, MetaFrame, MetaFrame XP sont des marques d�pos�es, et Citrix Presentation Server est une marque de fabrique, de commerce ou de service de Citrix Systems,Inc. aux �tats-Unis et dans d'autres pays.
- Bluetooth(R) est une marque d�pos�e de la Bluetooth SIG, lnc.
- Les autres noms de compagnies et noms de produits mentionn�s dans ce manuel sont les marques d�pos�es de leurs compagnies respectives.
